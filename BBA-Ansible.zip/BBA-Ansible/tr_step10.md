# 2. Senaryo
Bu senaryoda AWX kullanarak hedef makinelere servis kuracağız. 

### Bu senaryoda neler öğreneceğiz:
* Gitlab üzerinden private projenin AWX aktarımı,
* Workflow template oluşturulması,
* İş akışlarında onaya bağlı mekanizmaların oluşturulması,

## Uygulama
````
https://github.com/new
````
![dashboard](images/36.png "Title")

Yukarıdaki gitlab url kullanarak, gitlab hesabınızla private bir repo oluşturun.

````
https://github.com/mertkslkc/awx
````

![dashboard](images/35.png "Title")
Yukarıda yer alan gitlab url gidin packets.yaml ve start_service.yamllarının içeriğini oluşturduğunuz yeni private repoya kopyalayın.

````
https://github.com/settings/tokens/new
````
![dashboard](images/38.png "Title")
Yukarıdaki url giderek gitlab hesabınıza özel bir token almanız gerekmektedir. Bu token sayesinde AWX private repoyu içeri aktarabilir. Token bir isim girin ve repo kutusunu işaretleyip "Generate token" butonuna basın. Oluşturduğunuz token'ı kopyalayın.

![dashboard](images/39.png "Title")

Sol tarafta bulunan sekmelerden Resources > Credentials ekranına gidin. Açılan sayfada bulunan Add tıklayın.

* Name: Kimliğinize bir isim girin.
* Credential Type: "Source Control" seçin. Seçmemizdeki neden SCM (kaynak kontrolü) kimlik bilgileri, Git, Subversion veya Mercurial gibi bir uzaktan revizyon kontrol sisteminden yerel kaynak kodu havuzlarını klonlamak ve güncellemek için projelerle birlikte kullanılır.
* Username: Gitlab kullanıcı adınızı girin.
* Password: Gitlab üzerinden oluşturduğunuz token'ı girin.

