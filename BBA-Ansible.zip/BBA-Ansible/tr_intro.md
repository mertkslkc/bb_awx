# AWX 
AWX Eğitimine hoş geldin... 😊

İnteraktif örnekler ile Ansible AWX arayüzü ile tanışacak ve otomasyon işlemlerimizi nasıl kolayca yönetebileceğimizi göreceksiniz.

![Gif](https://media.tenor.com/M-ibWYQzmiIAAAAM/cat-cute.gif)

Kahven de hazırsa eğitime geçelim. 🚀  🚀  🚀 