### AWX Eğitimi Tamamlandı  
  
Tebrikler AWX eğitimini tamamladınız. 👏🏻

![finish](https://store.donanimhaber.com/05/01/14/0501143cc4efbf309eae1141fbf8a7b3.gif)

Profil sayfasına dönmek ve oturumu kapatmak için sonlandır butonuna basınız.
