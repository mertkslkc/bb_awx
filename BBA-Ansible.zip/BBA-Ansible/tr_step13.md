# 3. Senaryo 

Bu senaryoda AWX üzerinde rol ve sorumluklar ile AWX gerçekleşen olaylarla ilgili başka bir ortama bilgi aktarmaya bakacağız.

### Bu senaryoda neler öğreneceğiz:
* AWX kullanıcı bazlı girişi,
* Kullanıcılara rol ve sorumluluk atamayı.

## Uygulama

![dashboard](images/61.png "Title")

Sol tarafta bulunan sekmelerden Access > Users ekranına gidin. Açılan sayfada bulunan Add tıklayın. Burada kullanıcı adını ve ona dair bilgileri girdikten sonra User Type kısmında sizi 3 adet yetki düzeyi karşılamaktadır. Bunlar;

* Normal User: Kendilerine uygun roller ve ayrıcalıkların verildiği kaynaklarla (envanter, projeler ve iş şablonları gibi) sınırlı okuma ve yazma erişimine sahiptir.
* System Auditor: Oluşturulan tüm projeleri görür fakat, silemez
* System Administrator: Oluşturulan tüm projeleri görür yönetir ve silebilir. Kullanıcılara yetki atayabilir veya yetkisini kaldırabilir.

![dashboard](images/62.png "Title")

2 adet test kullanıcısı oluşturacağız. Bunlardan birisi normal user olurken bir diğerine de system auditor yetkisi verip aralarındaki farkları daha iyi anlayabiliriz.

![dashboard](images/63.png "Title")
Son durumda acces ekranında eklediğiniz 2 adet yeni user oluşturulmuş olacaktır. Bunların yetkilerini görmek için sağ üste bulunan Admin yazısına tıklayın ve çıkan Logout tıklayarak önce normal kullanıcısıyla sonra da auditor kullanıcıyısla giriş yapın.

