# 2.Resources

## Templates	

![dashboard](images/7.png "Title")

Templates, otomasyon görevleri oluşturmak için bir tanım ve parametreler kümesidir. Templates, aynı Job’u birçok kez yürütmek için kullanışlıdır. Bu ekranda bulunan Add sekmesinde Workflow Job Template ve Job Template olarak iki farklı Job türü mevcuttur.

* Job Template bir işi kapsayan görevdir.
* Workflow Job Template, birden fazla işi tek bir  görev altında birleştirmek için kullanılır. Yani birden fazla job templateler birleştirerek oluştuturalan otomasyon görevine workflow job template denir.

## Credentials

![dashboard](images/8.png "Title")

Credentials, AWX tarafında oluşturulmuş otomasyon görevlerinde hedef kaynaklara bağlanması için gerekli olan şifrelerin tutulduğu yerdir. Buna bir örnek vermek gerekirse AWX makinenizin Gitlab üzerinde tuttuğunuz playbookları aktarmasını istiyorsanız gitlab credentials, aktardığınız playbookları ilgili makinelerde çalıştırmak istiyorsanız da machine credentials tanımlamanız gerekmektedir.

## Projects

![dashboard](images/9.png "Title")

Projects, Gitlab gibi ortamlarda tutulan yaml dosyalarını AWX üzeri. Bune aktarmak için ve aktarılan bu dosyalardan otomasyon görevleri oluşturmak için kullanılır.

## Inventories

![dashboard](images/10.png "Title")

Inventories, bağlanmak istediğimiz sunucuları tuttuğumuz ve yönettiğimiz yer. Birden fazla sunucuda aynı işlemi yapmak için burada sunucuları gruplayabiliriz.

## Hosts

![dashboard](images/11.png "Title")

Hosts, otomasyon görevlerinin çalışacağı hedef makinelere ait bilgilerin tutulduğu yerdir.