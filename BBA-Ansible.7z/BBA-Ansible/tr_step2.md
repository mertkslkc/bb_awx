# AWX Giriş

![dashboard](images/01.png "Title")

Kurulum tamamlandıktan sonra terminal ekranınızın üstünde bulunan kısımdan node1 terminalini ve 80 portunu seçip sağ tarafta bulunan yeni sekme ikonuna tıklayarak AWX ekranına gidin.

![dashboard](images/02.png "Title")

Gelen uyarıyı atlamak için gelişmiş butonuna basın ve aşağıdaki URL'e tıklayıp devam edin.

![dashboard](images/03.png "Title")

Açılan AWX ekranına aşağıdaki bilgileri kullanarak giriş yapın.

* Username: admin
* Password: admin

Kurs akışını özetleyecek olursak, ilk olarak AWX ekranında bulunan içerikler hakkında bilgi sahibi olacağız. Hemen ardından çeşitli otomasyon senaryoları oluşturarak öğrendiğimiz bilgileri pekiştireceğiz.
