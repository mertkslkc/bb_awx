# 2. Senaryo
![dashboard](images/47.png "Title")

Save tıkladıktan sonra AWX sizi Visualizer ekranına yönlendirecek. Bu ekranda joblarınızı birbirinize bağlayabilir. Onay tabanlı mekanızmalar oluşturabilirsiniz.

![dashboard](images/48.png "Title")
Start butonuna tıkladığınızda karşınıza daha önce oluşturduğunuz iki job gelecektir. Bu joblardan önce packets.yaml seçiyorum çünkü makineye ilgili servisler bu job üzerinden kurulacaktır. Ardından save tıklıyorum.

![dashboard](images/49.png "Title")
Workflow template ekranıma ilk job dahil ettim. Eklediğim Job'ın üzerine geldiğimde yan tarafta açılan küçük bir sekme açılacaktır. Bu sekmede + ikonu ile packets.yaml job'ma başla bir job bağlayabilir, i ikonu ile job'a ait detayları görebilir, kalem ikonu ile yeniden job seçebilir, bağlantı ikonu ile başka bir adıma job'u bağlayabilir ve silme ikonu ile job'u workflow template üzerinden silebilirsiniz.

![dashboard](images/50.png "Title")
packets.yaml job'nu start_servis.yaml job'na bağlamak için + ikonuna tıklayın. Burada sizi koşul ekranı karşılayacaktır. Bu ekranda 3 adet koşul mevcuttur bunlar;

* On Succes: Çalıştırılan Job sadece başarılı olursa bir sonraki adıma geçmek için kullanılır.
* On Failure: Çalıştırılan Job sadece başarısız olursa bir sonraki adıma geçmek için kullanılır.
* Always: Çalıştırılan Job sadece başarılı veya başarısız olmasına bakmaksızın bir sonraki adıma geçmek için kullanılır.

![dashboard](images/51.png "Title")
start_service.yaml seçin ve save butonuna tıklayın.

![dashboard](images/58.png "Title")
Son durumda workflow ekranınız bu şekilde görülecektir. Fakat bu akışa bir de onay mekanizması ekleyelim bunun için iki job'un arasına geldiğinizde çıkan + ikonuna tıklayın.

![dashboard](images/52.png "Title")
Onaya bağlı mekanizmalar oluşturmak için Node Type kısmını Approval olarak seçin. Tİmeout kısmı ise bu onayın ne kadar bekleneceği süredir. Örnekte 10 dakika girilmiştir şayet bu süre içinde onay verilmez ise otomatik olarak onaylanmamış kabul edilir.
![dashboard](images/53.png "Title")
Son durumda Workflow Template ekranınız yukarıdaki gibi görüntülencektir.

![dashboard](images/54.png "Title")
Resources > Templates sekmesine gidin. Oluşturduğunuz workflow templates yanında bulunan roket simgesine tıklayarak job'u launch (başlat) edin.

![dashboard](images/55.png "Title")
Workflow template'in iş akışını izlediğinizde packets.yaml job'nun başarılı bir şekilde çalıştığını fakat bir sonraki adım olan Kurulum Onayı Job'unda takıldığını fark edeceksiniz.start_service.yaml job'nun başlatılabilmesi için yöneti onayı alınması gerekmektedir.

![dashboard](images/56.png "Title")
Views > Workflow Approvals sekmesine gidin. Burada System Administrator ekranına bir adet onay sorusu gelmiştir. Soruya tıklayın ve Approve butonuna basarak bu job'un devam etmesi için gereken onayı verebilirsiniz.

![dashboard](images/57.png "Title")
Yönetici onayı da alındığına göre start_service.yaml job'nun çalıştığını ve tüm jobların tek bir template altında birleştirilerek tek seferde iş akışı şeklinde çalıştığını gözlemledik.

![dashboard](images/59.png "Title")
Terminal ekranına dönün yukarıda bulunan kısımdan node2 ve 80 portunu seçip ilgili adrese gitmek için sekme ikonuna tıklayın. 

![dashboard](https://media.tenor.com/PgVIwnUksdAAAAAC/it-works-yes.gif "Title")

İlgili sekmeye gittiğinizde apache servisinin 80 portunda node2 ve node3 de aktif bir şekilde çalıştığını görebilirsiniz.