# 4.Administraion

## Credential Types	

![dashboard](images/16.png "Title")

Credential Types, administrator erişimine sahip bir AWX admini, Job ve inventory güncellemelerine yeni credential türlerinin atanmasına olanak tanıyan YAML/JSON benzeri bir tanım kullanarak standart biçimde özel bir credential türü tanımlayabilir. Bu, mevcut credential türlerine benzer şekillerde çalışan özel bir credential türü tanımlamanıza olanak tanır. Örneğin, bir ortam değişkenine üçüncü taraf bir web hizmeti için bir API belirteci enjekte eden ve playbook veya özel inventory komut dosyanızın kullanabileceği özel bir credential türü oluşturabilirsiniz. 

## Notification Templates	

![dashboard](images/17.png "Title")

Notification Templates, AWX üzerinde yapılan işler hakkında dış tarafa başarılı veya başarısız gibi bilgilerinin aktarıldığı kısımdır. Örneğin oluşturduğunuz job'un başarılı bir şekilde çalıştıktan sonra size mail üzerinen bilgi vermesini istiyorsanız buradan mail bildirimi oluşturubilirsiniz.

## Management Jobs	

![dashboard](images/18.png "Title")

Management Jobs, sistem izleme bilgileri, job geçmişleri ve etkinlik akışları dahil olmak üzere AWX'deki eski verilerin temizlenmesine yardımcı olur. Belirli saklama ilkeleriniz varsa veya Tower veritabanınız tarafından kullanılan depolama alanını azaltmanız gerekiyorsa bunu kullanabilirsiniz.

## Instance Groups	

![dashboard](images/19.png "Title")

Instance Groups, büyük otomasyon işleri için birden fazla ansible makineniz olabilir bunlar için tek tek AWX yüklemek yerine tüm ansible makinelerinizi Instance Groups	altında toplayabilirsiniz.

## Applications	

![dashboard](images/20.png "Title")

Token tabanlı uygulamalar geliştirmek için kullanılır. Örneğin ansible üzerinde job başlatmak için gerekli bilgilerin dış tarafından AWX aktarılması için kullanılır.