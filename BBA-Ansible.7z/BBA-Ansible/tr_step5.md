# 3. Access

## Organizations

![dashboard](images/12.png "Title")

Organizations, Ansible kurulumunuz için mevcut tüm kuruluşları görüntüler. Self-Support düzeyinde lisansa sahip AWX kullanıcıları yalnızca varsayılan organizasyona sahiptir ve bunu silmemelidir

![dashboard](images/13.png "Title")

Organizationslar; teams, project ve inventories oluşan mantıksal bir kümedir ve AWX nesne hiyerarşisindeki en yüksek seviyedir.

## Users	

![dashboard](images/14.png "Title")

Users, ilişkili izinler ve credentials ile AWX erişimi ayarlamak için kullanılır. 

Üç tip User Type vardır:

* Normal User, kullanıcıya uygun roller ve ayrıcalıkların verildiği kaynaklarla (inventory, projects ve job templates gibi) sınırlı okuma ve yazma erişimine sahiptir.
* System Auditor, AWX ortamındaki tüm nesneler için salt okunur özelliğini dolaylı olarak devralır.
* System Administrator, AWX için tam sistem yönetimi ayrıcalıklarına sahiptir. Tüm AWX kurulumunda tam okuma ve yazma ayrıcalıkları vardır. System Administrator, genellikle AWX'ın tüm yönlerini yönetmekten ve çeşitli Kullanıcılara günlük işler için sorumlulukları devretmekten sorumludur.

Hatırlayacağınız üzere biz tower'a admin ile giriş yapmıştık yukarıdaki fotoğrafta da görüleceği üzere admin'e verilen yetki System Adminstrator.

## Teams

![dashboard](images/15.png "Title")

Teams, users, projects, credentials ve izinlere sahip bir organization’ın alt bölümüdür. Teams, rol tabanlı erişim kontrol şemalarını uygulamak ve organizations arasında sorumlulukları devretmek için bir araç sağlar. Örneğin, izinler Teams’deki her kullanıcı ayrı ayrı vermek yerine tüm Teams’e aynı yetki verilebilir.