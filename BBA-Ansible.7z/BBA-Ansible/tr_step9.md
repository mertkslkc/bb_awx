# 1. Senaryo
![dashboard](images/25.png "Title")
Sol tarafta bulunan sekmelerden Resources > Templates ekranına gidin. Açılan sayfada bulunan Add > Add Job Template tıklayın.

![dashboard](images/30.png "Title")
Bu ekranda yazılan yamlları çalıştıracak otomasyon görevini oluşturacağız. 

* Name: Otomasyon görevimize bir isim verdik, ufak bir tavsiye template ile project Job ekranında izlerken hangisinin template hangisinin project olduğunu kolay ayırt etmek için name ilglili template'nin çalıştırdığı dosyanın adını verebilirsiniz.

* Inventory: Hedef makineler için oluşturduğumuz kümenin adı olan "Terminal Makinelerim" seçtik.
* Project: Bu job'un "1.Senaryo" bağlı olduğundan seçildi.
* Playbook: Gitlab üzerinden örnek çektiğimiz yamllardan "group_test.yaml" seçiyoruz. Bu yaml ilgili makinelere gidip mert isimli gruplar oluşturacak.
* Credentials: Ansible makinesinin hedef makinelere bağlanabilmesi için makinelerin ortak şifresini tanımladığımız "Makine Kimliği" seçtik.

Yukarıdaki tanımları yaptıktan sonra save tıklayın.

![dashboard](images/32.png "Title")

Job oluşturulduktan sonra açılan ekranda bulunan Launch butonuna tıklayarak otomasyonu başlatın.

![dashboard](images/33.png "Title")

Otomasyonu başlattıktan sonra sizi otomasyona ait konsol ekranına aktarıcaktır. Buradan otomasyona ait çıktıları inceleyebilirsiniz. Şayet yanlış bir adım uygulamadıysanız node2 ve node3 için çıktılar ok olacaktır.

![dashboard](images/31.png "Title")

Templates ekranına tekrar dönün. Oluşturulan job'ın sağ kısmında bulunan Roket ikonu yine launch butonu gibi otomasyonu başlatmak içindir. Onun yanında bulunan kalem ikonu ise ilgili job'ı düzenlemek için kullanılır. Ortada bulunan yeşil kutu ise job çalıştığı zamanlara ait konsol çıktılarını görebilirsiniz.

![dashboard](images/34.png "Title")
````
cat /etc/group |grep mert
````
Terminal ekranınıza dönerek otomasyonun çalıştığı hedef makineleri kontrol etmek amaçlı node2 ve node3 gidin. Ardından yukarıdaki komutu konsola yapıştırarak node2 ve node3 için AWX üzerinden oluşturduğumuz grup oluşturma otomasyonun başarılı bir şekilde çalıştığını görebilirsiniz.