# 1.Views	

## Dashboard

![dashboard](images/1.png "Title")

Dashboard; hostların, envanterin ve projelerin bir özetiyle başlar. Bunların her biri, kolay erişim için AWX'deki ilgili nesnelerle bağlantılıdır. Bu ekran üzerinden, mevcut iş akışlarınızı listeleyen bir özet görünür. Ayrıca, son kullanılan şablonlar ve çalışan otomasyonların özetleri de belirli bir süre boyunca başarılı ve başarısız işlerin sayısını görüntülenir. 

## Jobs

![dashboard](images/2.png "Title")

Jobs, çalıştırılan otomasyon görevine ait project, template ve jobların durumlarını özetleyen ekrandır. 

![dashboard](images/3.png "Title")

Konsol çıktısını incelemek istediğiniz Job'a tıklayarak otomasyon görevine ait detayların sonuçlarını inceleyebilirsiniz.

## Schedules

![dashboard](images/4.png "Title")

Schedules, belirli zaman aralıklarında otomatik olarak çalışmasını istediğiniz işlerinizi planlayabileceğiniz kısımdır.

## Activity Stream

![dashboard](images/5.png "Title")

Activity Stream, belirli bir nesne için tüm değişiklikleri gösterir. çalıştırılma zamanı, her değişiklik için olayın saatini, olayı başlatan kullanıcıyı ve eylemi gösterir.

## Workflow Approvals

![dashboard](images/6.png "Title")

Workflow Approvals, birkaç adımdan oluşan bir iş akışında onaya bağlı mekanizmalar oluşturmak için kullanılır. 