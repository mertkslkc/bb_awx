# 1. Senaryo

Bu senaryoda AWX kullanarak hedef makinelerde group oluşturacağız. 

### Bu senaryoda neler öğreneceğiz:
* Gitlab üzerinden public projenin AWX aktarımını,
* AWX Project ve Job oluşturmayı,
* Host ekleme ve Inventories yönetimini,
* Çalıştırılan Jobların konsol çıktılarını,
* Credentials ile ansible hedef makinelere bağlanmayı.

## Uygulama

![dashboard](images/21.png "Title")

Sol tarafta bulunan sekmelerden Resources > Project ekranına gidin. Açılan sayfada bulunan Add butonuna basın.

![dashboard](images/22.png "Title")

Project ekranı sizden bazı parametreler beklemektedir bunlar;

* Name: Projenize bir isim verin

* Description: Projeniye isteğe bağlı bir açıklama girmek için kullanılır.

* Source Control Credential Type: AWX dışarıdan dosya aktarmak için seçilecek kaynak tipi bu örnekte benim test yaml olduğu ortam gitlab olduğundan Git olarak seçim yaptım sizde Git seçebilirsiniz.

* Source Control URL: Dosyanın aktarılacağı yolu vermeniz gerekiyor. Aşağıdaki url bu alana girin.
````
https://github.com/mertkslkc/awx.git
````
* Source Control Branch: Git üzerinden pull edeğimizden dolayı brach girmemiz gerekmektedir. Benim sizler için oluşturduğum brach main üzerindendir bundan dolayı bu alana main girin.

* Source Control Credential: Gitlab üzerinden çektiğimiz bu repo publictir. Dolayısıyla herhangi bir credential girmemiz şuanlık gerekmiyor. İlerleyen senaryolarda kendi gitlabımız üzerinde  private bir repo oluşturarak gitlab credential ile nasıl proje aktarıldığına değineceğiz.

* Update Revision on Launch: Bu kutuyu seçerek aslında ilgili url'de bulunan dosyada herhangi bir güncelleme varsa job çalıştırılmadan önce en güncel dosyayı getirir ve mevcut job görevini bu dosya üzerinden gerçekleştirir. 

İlgili alanları doldurduktan sonra Save butonuna basın.

![dashboard](images/23.png "Title")

Project ekranına tekrar döndüğünüzde projenizin sağ tarafında bulunan yenileme ikonuna basarak proje dosyalarını güncelleyebilir kalem ikonu ile de projenizi tekrar düzenleyebilirsiniz. Yine proje isminin yanında bulunan yeşil kutu ise başarılı bir şekilde proje oluşturduğunuz anlamına gelir. Yeşil kutuya tıklayarak projenize ait çıktıları görebilirsiniz.

![dashboard](images/24.png "Title")

Bu ekrandan projeye ait çıktıları inceleyebilirsiniz.