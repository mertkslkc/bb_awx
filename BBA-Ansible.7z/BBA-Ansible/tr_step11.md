# 2. Senaryo
![dashboard](images/40.png "Title")

Sol tarafta bulunan sekmelerden Resources > Project ekranına gidin. Açılan sayfada bulunan Add tıklayın.

1 . senaryoda public project oluşturmayı öğrenmiştik. Bu senaryoda privete project AWX dahil edeceğimizden Source Control Credential sekmesinden  oluşturduğumuz gitlab_token seçiyoruz.

* Source Control Credential Type: Git
* Source Control URL: Private gitlab url
* Source Control Branch: main
* Update Revision on Launch: En güncel repoyu çekmesi için seçilir.

![dashboard](images/41.png "Title")

Templates sekmesine gitmeden de project ekranında bulunan Job Templates sekmesine tıklayarak oluşturduğunuz projeye ait jobları görebilir yeni joblar oluşturabilirsiniz. Ayrıca yine bu ekranda bulunan Sync butonu ile projelerinizi güncelleyebilir aynı zamanda düzenleyebilir veya silebilirsiniz.

![dashboard](images/42.png "Title")
packet.yaml job'u oluşturuldu.

![dashboard](images/43.png "Title")
start_service.yaml job'u oluşturuldu.

![dashboard](images/44.png "Title")

Son durumda template ekranınız da oluşturulmuş iki adet job template olacaktır. Bu joblardan packet.yaml job'u node2 ve node3 bağlanarak apache servisini kurarken, start_service.yaml job'u ise bu servisi nodelarda başlatmak için kullanılacaktır. Görüleceği üzere iki adet gerçekleştirmem geren görev var bunu ayrı ayrı çalıştırmaktansa bu jobları tek bir workflow template toplayıp kullanacağız.

![dashboard](images/46.png "Title")

Workflow template oluşturmak için Resources > Templates sekmesine gidin. Açılan sayfada Add > Add workflow template seçin.
* Name: Workflow template isim girin.
* Inventory: Bu template'in çalıştırılacağı hedef makine kümesini girin. Node2 ve Node3 makinelerimiz Terminal Makinelerim kümesinin içindeydi.
* Organization: Default olarak seçin.
Gerekli tanımları yaptıktan sonra Save tıklayın.




