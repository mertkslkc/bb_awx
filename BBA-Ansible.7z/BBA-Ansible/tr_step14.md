# 3. Senaryo
![dashboard](images/65.png "Title")
AWX giriş ekranına oluşturduğumuz normal user ile giriş yapın.

![dashboard](images/64.png "Title")
Ardından sol tarafta bulunan sekmelerden Resources > Project ekranına gidin. Görüleceği üzere normal user projelere yetki olarak atanmadığı sürece hiçbir projeyi göremiyor.

![dashboard](images/66.png "Title")
AWX giriş ekranına oluşturduğumuz normal auditor ile giriş yapın.

![dashboard](images/67.png "Title")
Sol tarafta bulunan sekmelerden Resources > Project ekranına gidin. Görüleceği üzere auditor user oluşturulan tüm projeleri görüntülüyebiliyor. Fakat proje özelinde yetki verilmediğinden projeleri ne launch edebilir ne de silebilir.

![dashboard](images/68.png "Title")
Proje özelinde yetki vermek amacıyla admin kullanıcısıyla tekrar giriş yapın.

![dashboard](images/69.png "Title")
Sol tarafta bulunan sekmelerden Access > Users ekranına gidin. normal kullanıcısının üzerine tıklayın ve açılan sayfada bulunan Roles sekmesini seçin. Bu sayfada bulunan Add butonuna basın.

![dashboard](images/70.png "Title")
Açılan sayfada normal kullanıcısına izin vereceğiniz bölümler çıkmaktadır. Ben normal kullanıcısının projeleri görmesini istediğimden Projects seçeneğini seçiyorum ve Next' basıyoruz.

![dashboard](images/71.png "Title")
Görüntülenmesini istediğim projeyi seçiyorum ve next tıklıyorum.

![dashboard](images/72.PNG "Title")
Burada normal kullanıcısına vereceğim sorumluluğu seçiyorum.

* Admin: Seçilen proje üzerinde tam yetkisi olur, projeyi silebilirveya düzenleyebilir.
* Use: Projeye bağlı Job templateler oluşturabilir.
* Update: Projeyi sadece günceller yani sync eder.
* Read: Projeyi görüntülüyebilir fakat işlem yapamaz.

Ben burada normal kullanıcısına Update ve Read yetkisi vererek projeyi görüntüleyip aynı zamanda da güncelleme (sync) yetkisi veriyorumç
![dashboard](images/73.PNG "Title")
Normal kullanıcısıyla tekrar giriş yaptığınızda project ekranında bulunan Demo Project üzerinde görüntüleme ve güncelleme (sync) yetkisi olduğunu görebilirsiniz.