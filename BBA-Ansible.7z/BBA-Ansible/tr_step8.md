# 1. Senaryo

![dashboard](images/26.png "Title")

Sol tarafta bulunan sekmelerden Resources > Inventories ekranına gidin. Açılan sayfada bulunan Add tıklayın. Name kısmına terminal makinelerimizi gruplayacağımız küme ismini girin ve save ile kaydedin.

![dashboard](images/0.png "Title")
Terminal ekranıma dönerek node2 ve node3 makineleriminin ip bilgilerine bakıyorum.
Sol tarafta bulunan sekmelerden Resources > Hosts ekranına gidin. 

![dashboard](images/27.png "Title")

Açılan sayfada bulunan Add tıklayın. Buraya terminal makinelerimizin ip bilgilerini Variables kısmına aşağıdaki şablonu kullanarak girin. 

````
ansible_host: 10.0.170.4
````
Inventory kısmına ise oluşturduğunuz kümenin adını girin.

![dashboard](images/28.png "Title")

Hosts ekranına tekrar dönecek olursak sağ tarafta bulunan butonlardan ilglili otomasyonun çalışmasını istemediğiniz makineyi pasif duruma getirebilirsiniz. Yine inventory kısmında ise bu makinenin hangi kümenin bir üyesi olduğu görünmektedir.

![dashboard](images/29.png "Title")

Sol tarafta bulunan sekmelerden Resources > Credentials ekranına gidin. Açılan sayfada bulunan Add tıklayın. Name kısmından kimliğimize bir isim verdikten sonra Credential Type sekmesinden Machine seçiyoruz. Machine seçmemizdeki amaç ansible makinesinin hedef makinelere bağlanabilmesidir.

* Username: root
* Password: root

















